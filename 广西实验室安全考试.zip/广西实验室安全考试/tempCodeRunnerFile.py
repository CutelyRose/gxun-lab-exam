    # shipin(token,towcode)
    # lianxi(token,towcode,id)
    # exam(token,id,1)