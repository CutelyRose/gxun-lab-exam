# 假设已收集到的答案片段
import json
radio_parts = ['3017-A', '3013-D', '3018-A']
check_parts = ['3036-D|B|C', '3029-B|A|C|D']
judge_parts = ['3004-Y', '3010-N']

# 拼成服务器要的字符串
radio_str = 'A@' + ','.join(radio_parts)
check_str = 'B@' + ','.join(check_parts)
judge_str = 'C@' + ','.join(judge_parts)

# 最终 payload
payload = {
    "PaperID": "277112",
    "radio": radio_str,
    "check": check_str,
    "judge": judge_str,
    "jianda": "E@",
    "type": 3,
    "RadioGroup": "0",
    "maxtime": "7143"
}

print(json.dumps(payload, ensure_ascii=False))